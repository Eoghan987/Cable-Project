% Program to determine the WCW and wrench feasible workspace (WCF) of a planar cable robot, 
% with 3 cables whose actuators are located on a square

clear all;
clc;

tic

% Degree of discretization, ie. number of points per row and column. Change as required.
gridSize = 100;
% Step size in mm. Do not change.
stepSize = 1000 / gridSize; 

% Cable Tension Limits for WFW
minTension = 0.5;
maxTension = 4;
targetForce = 0.5;

% ***Order of attachment points must be A,B,C(anticlockwise)*** 
%Attachment point coordinates in mm
%A
Ax = 0;
Ay = 0;
%B
Bx = 1000;
By = 0;
%C
Cx = 500;
Cy = 1000;

% MP position (for graphs)
MPx = 500;
MPy = 500;

% Preallocate vectors for x and y coordinates
X = zeros(gridSize^2,1); 
Y = zeros(gridSize^2,1); 

% Preallocate force direction vectors (cable pair bisectors)
V_OA = zeros(gridSize^2,2);
V_OB = zeros(gridSize^2,2);
V_OC = zeros(gridSize^2,2);

angleAOB = zeros(gridSize^2,1);
angleBOC = zeros(gridSize^2,1);
angleCOA = zeros(gridSize^2,1);

%Iterate through work space
for i = 1:gridSize
    
    for j = 1:gridSize
        
        % Get row index of current point
        index = gridSize*(i-1)+j;
        
        % Get x and y coordinate of current point
        X(index) = stepSize/2 + (i-1)*stepSize;
        Y(index) = stepSize/2 + (j-1)*stepSize;
        
        %Find componenets of position vectors
        V_OA(index,:) = [Ax-X(index),Ay-Y(index)];
        V_OB(index,:) = [Bx-X(index),By-Y(index)];
        V_OC(index,:) = [Cx-X(index),Cy-Y(index)];
        

        %Find the 3 angles
        angleAOB(index) = atan2(V_OA(index,1)*V_OB(index,2)-V_OA(index,2)*V_OB(index,1),V_OA(index,1)*V_OB(index,1)+V_OA(index,2)*V_OB(index,2));
        angleBOC(index) = atan2(V_OB(index,1)*V_OC(index,2)-V_OB(index,2)*V_OC(index,1),V_OB(index,1)*V_OC(index,1)+V_OB(index,2)*V_OC(index,2));
        angleCOA(index) = atan2(V_OC(index,1)*V_OA(index,2)-V_OC(index,2)*V_OA(index,1),V_OC(index,1)*V_OA(index,1)+V_OC(index,2)*V_OA(index,2));
        
    end
    
end


% Combine vectors to form an array for filtering
combined1 = [X,Y,angleAOB,angleBOC,angleCOA,V_OA,V_OB,V_OC];

% Remove rows with negative angles. These represent an angle greater than
% 180 degrees measured anticlockwise from one cable to the next.
TF1 = combined1(:,3)<=0; 
TF2 = combined1(:,4)<=0;
TF3 = combined1(:,5)<=0;
TFall1 = TF1 | TF2 | TF3;
combined1(TFall1,:) = [];

% Split the array back into individual column vectors

% Number of points remaining
WCWsize = length(combined1);

% New vectors for the coordinates of remaining points
newX = combined1(:,1);
newY = combined1(:,2);

% New vectors for attachment point positions from remaining points
newV_OA(:,1) = combined1(:,6);
newV_OA(:,2) = combined1(:,7);
newV_OB(:,1) = combined1(:,8);
newV_OB(:,2) = combined1(:,9);
newV_OC(:,1) = combined1(:,10);
newV_OC(:,2) = combined1(:,11);

%Preallocate vectors for forces that can be applied in 6 limiting directions
%(perpendicular distance from origin to sides of force polygon)
side1 = zeros(WCWsize,1);
side2 = zeros(WCWsize,1);
side3 = zeros(WCWsize,1);
side4 = zeros(WCWsize,1);
side5 = zeros(WCWsize,1);
side6 = zeros(WCWsize,1);

for i = 1:WCWsize
    

     % Find the 3 bisector angles (with respect to positive x-axis)
     forceA = atan2(newV_OA(i,2),newV_OA(i,1));
     forceB = atan2(newV_OB(i,2),newV_OB(i,1));
     forceC = atan2(newV_OC(i,2),newV_OC(i,1));
     
     % Find maximum and minimum forces
     minA = [minTension*cos(forceA) minTension*sin(forceA)];
     maxA = [maxTension*cos(forceA) maxTension*sin(forceA)];
     
     minB = [minTension*cos(forceB) minTension*sin(forceB)];
     maxB = [maxTension*cos(forceB) maxTension*sin(forceB)];
     
     minC = [minTension*cos(forceC) minTension*sin(forceC)];
     maxC = [maxTension*cos(forceC) maxTension*sin(forceC)];
     
     
     % Find vertices of force hexagon
     vertex1 = maxA+minB+minC;
     vertex2 = maxA+maxB+minC;
     vertex3 = minA+maxB+minC;
     vertex4 = minA+maxB+maxC;
     vertex5 = minA+minB+maxC;
     vertex6 = maxA+minB+maxC;
     
     % Find "distance" to each side of force hexagon (ie. max force that can be
     % applied in each of limiting directions)
     side1(i) = signedPointLineDistance(0,0,vertex1(1),vertex1(2),vertex2(1),vertex2(2)); %Side between vertices 1 and 2
     side2(i) = signedPointLineDistance(0,0,vertex2(1),vertex2(2),vertex3(1),vertex3(2));
     side3(i) = signedPointLineDistance(0,0,vertex3(1),vertex3(2),vertex4(1),vertex4(2));
     side4(i) = signedPointLineDistance(0,0,vertex4(1),vertex4(2),vertex5(1),vertex5(2));
     side5(i) = signedPointLineDistance(0,0,vertex5(1),vertex5(2),vertex6(1),vertex6(2));
     side6(i) = signedPointLineDistance(0,0,vertex6(1),vertex6(2),vertex1(1),vertex1(2)); %Side between vertices 6 and 1
       
end


combined2 = [newX,newY,side1,side2,side3,side4,side5,side6];
    
TF4 = abs(combined2(:,3))<=targetForce ; %Note difference in Boolean variable number and side index
TF5 = abs(combined2(:,4))<=targetForce; 
TF6 = abs(combined2(:,5))<=targetForce; 
TF7 = abs(combined2(:,6))<=targetForce; 
TF8 = abs(combined2(:,7))<=targetForce; 
TF9 = abs(combined2(:,8))<=targetForce;
TF10 = combined2(:,3)>=0; 
TF11 = combined2(:,4)>=0; 
TF12 = combined2(:,5)>=0; 
TF13 = combined2(:,6)>=0; 
TF14 = combined2(:,7)>=0;
TF15 = combined2(:,8)>=0;

TFall2 = TF4 | TF5 | TF6 | TF7 | TF8 | TF9 | TF10 | TF11 | TF12 | TF13 | TF14 | TF15;
combined2(TFall2,:) = [];

WFWsize = length(combined2);

xWFW = combined2(:,1);
yWFW = combined2(:,2);


% Plot workspaces
figure
hold on;

% CHANGE COLOURS FOR NEXT PRESENTATION

% Plot WCW and WFW
h1 = scatter(combined1(:,1),combined1(:,2),50,'.','y');
h2 = scatter(combined2(:,1),combined2(:,2),50,'.','g');

% Plot circles at all attachment points, one colour per differential
attachmentA = [Ax Ay];
attachmentB = [Bx By];
attachmentC = [Cx Cy];

h3 = scatter(attachmentA(:,1),attachmentA(:,2),100,'filled','o','r');
h4 = scatter(attachmentB(:,1),attachmentB(:,2),100,'filled','o','c');
h5 = scatter(attachmentC(:,1),attachmentC(:,2),100,'filled','o','k');



plot([MPx Ax], [MPy Ay],'r')
plot([MPx Bx], [MPy By],'c')
plot([MPx Cx], [MPy Cy],'k')

h6 = scatter(MPx,MPy,100,'filled','o','b');

xlabel({'x','/mm'})
ylabel({'y','/mm'})
axis equal;
xlim ([0 1000])
ylim ([0 1000])
legend([h1 h2 h3 h4 h5 h6],{'WCW','WFW','Attachment A', 'Attachment B', 'Attachment C','MP'});

hold off;

% Workspace area calculation
WCWarea = WCWsize/gridSize^2
WFWarea = WFWsize/gridSize^2


% %Write points in WFW to CSV
% WFW = [xWFW,yWFW];
% filename = 'WFW.csv';
% csvwrite(filename,WFW)

toc