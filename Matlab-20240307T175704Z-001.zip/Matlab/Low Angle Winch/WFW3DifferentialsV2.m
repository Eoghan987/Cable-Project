% Program to determine wrench feasible workspace (WCF) of a planar cable robot, 
% (driven by 3 cable differentials with attachment points on the perimeter of a 1m square).

clear all;
clc;

tic

% Degree of discretization, ie. number of points per row and column. Change as required.
gridSize = 100;
% Step size in mm. Do not change.
stepSize = 1000 / gridSize; 

% Cable Tension Limits for WFW
minTension = 0.5;
maxTension = 15;
targetForce = 0.5;

% ***Order of attachment points must be A1,A2,B1,B2,C1,C2(anticlockwise)*** 
%Attachment point coordinates in mm
%A
A1x = 0;
A1y = 0;
A2x = 900; 
A2y = 0;
%B
B1x = 1000;
B1y = 100;
B2x = 1000;
B2y = 1000;
%C
C1x = 100;
C1y = 1000;
C2x = 0;
C2y = 900;

% MP position (for graphs)
MPx = 500;
MPy = 500;

% Preallocate vectors for x and y coordinates
X = zeros(gridSize^2,1); 
Y = zeros(gridSize^2,1); 

% Preallocate position vectors (from base to attachment points)
V_OA1 = zeros(gridSize^2,2);
V_OA2 = zeros(gridSize^2,2); 
V_OB1 = zeros(gridSize^2,2);
V_OB2 = zeros(gridSize^2,2);
V_OC1 = zeros(gridSize^2,2);
V_OC2 = zeros(gridSize^2,2);

% Preallocate force direction vectors (cable pair bisectors)
V_OA = zeros(gridSize^2,2);
V_OB = zeros(gridSize^2,2);
V_OC = zeros(gridSize^2,2);

% Preallocate vectors for angles between the resultant forces of adjacent
%differentials
angleAOB = zeros(gridSize^2,1); % Angle AOB measure anticlockwise from OA to OB etc.
angleBOC = zeros(gridSize^2,1);
angleCOA = zeros(gridSize^2,1); 

%Iterate through work space
for i = 1:gridSize
    
    for j = 1:gridSize
        
        % Get row index of current point
        index = gridSize*(i-1)+j;
        
        % Get x and y coordinate of current point
        X(index) = stepSize/2 + (i-1)*stepSize;
        Y(index) = stepSize/2 + (j-1)*stepSize;
        
        %Find componenets of position vectors
        V_OA1(index,:) = [A1x-X(index),A1y-Y(index)];
        V_OA2(index,:) = [A2x-X(index),A2y-Y(index)];
        V_OB1(index,:) = [B1x-X(index),B1y-Y(index)];
        V_OB2(index,:) = [B2x-X(index),B2y-Y(index)];
        V_OC1(index,:) = [C1x-X(index),C1y-Y(index)];
        V_OC2(index,:) = [C2x-X(index),C2y-Y(index)];
        
        %Normalise vectors
        V_OA1(index,:) = V_OA1(index,:)/norm(V_OA1(index,:));
        V_OA2(index,:) = V_OA2(index,:)/norm(V_OA2(index,:));
        V_OB1(index,:) = V_OB1(index,:)/norm(V_OB1(index,:));
        V_OB2(index,:) = V_OB2(index,:)/norm(V_OB2(index,:));
        V_OC1(index,:) = V_OC1(index,:)/norm(V_OC1(index,:));
        V_OC2(index,:) = V_OC2(index,:)/norm(V_OC2(index,:));
        
        %Find resultant force direction for each differential
        V_OA(index,:) = V_OA1(index,:)+V_OA2(index,:);
        V_OB(index,:) = V_OB1(index,:)+V_OB2(index,:);
        V_OC(index,:) = V_OC1(index,:)+V_OC2(index,:);
           
        %Find the 3 angles
        angleAOB(index) = atan2(V_OA(index,1)*V_OB(index,2)-V_OA(index,2)*V_OB(index,1),V_OA(index,1)*V_OB(index,1)+V_OA(index,2)*V_OB(index,2));
        angleBOC(index) = atan2(V_OB(index,1)*V_OC(index,2)-V_OB(index,2)*V_OC(index,1),V_OB(index,1)*V_OC(index,1)+V_OB(index,2)*V_OC(index,2));
        angleCOA(index) = atan2(V_OC(index,1)*V_OA(index,2)-V_OC(index,2)*V_OA(index,1),V_OC(index,1)*V_OA(index,1)+V_OC(index,2)*V_OA(index,2));
        
    end
    
end


% Combine vectors to form an array for filtering
combined1 = [X,Y,angleAOB,angleBOC,angleCOA,V_OA,V_OA1,V_OA2,V_OB,V_OB1,V_OB2,V_OC,V_OC1,V_OC2];

% Remove rows with negative angles. These represent an angle greater than
% 180 degrees measured anticlockwise from one cable to the next.
TF1 = combined1(:,3)<=0; 
TF2 = combined1(:,4)<=0;
TF3 = combined1(:,5)<=0;
TFall1 = TF1 | TF2 | TF3;
combined1(TFall1,:) = [];

% Split the array back into individual column vectors

% Number of points remaining
WCWsize = size(combined1,1);

% New vectors for the coordinates of remaining points
newX = combined1(:,1);
newY = combined1(:,2);

% New vectors for attachment point positions from remaining points
newV_OA(:,1) = combined1(:,6);
newV_OA(:,2) = combined1(:,7);
newV_OA1(:,1) = combined1(:,8);
newV_OA1(:,2) = combined1(:,9);
newV_OA2(:,1) = combined1(:,10);
newV_OA2(:,2) = combined1(:,11);
newV_OB(:,1) = combined1(:,12);
newV_OB(:,2) = combined1(:,13);
newV_OB1(:,1) = combined1(:,14);
newV_OB1(:,2) = combined1(:,15);
newV_OB2(:,1) = combined1(:,16);
newV_OB2(:,2) = combined1(:,17);
newV_OC(:,1) = combined1(:,18);
newV_OC(:,2) = combined1(:,19);
newV_OC1(:,1) = combined1(:,20);
newV_OC1(:,2) = combined1(:,21);
newV_OC2(:,1) = combined1(:,22);
newV_OC2(:,2) = combined1(:,23);


%Preallocate vectors for forces that can be applied in 6 limiting directions
%(perpendicular distance from origin to sides of force polygon)
side1 = zeros(WCWsize,1);
side2 = zeros(WCWsize,1);
side3 = zeros(WCWsize,1);
side4 = zeros(WCWsize,1);
side5 = zeros(WCWsize,1);
side6 = zeros(WCWsize,1);

for i = 1:WCWsize
    
     % Find the angle on each differential
     angleDiffA = atan2(newV_OA1(i,1)*newV_OA2(i,2)-newV_OA1(i,2)*newV_OA2(i,1),newV_OA1(i,1)*newV_OA2(i,1)+newV_OA1(i,2)*newV_OA2(i,2));
     angleDiffB = atan2(newV_OB1(i,1)*newV_OB2(i,2)-newV_OB1(i,2)*newV_OB2(i,1),newV_OB1(i,1)*newV_OB2(i,1)+newV_OB1(i,2)*newV_OB2(i,2));
     angleDiffC = atan2(newV_OC1(i,1)*newV_OC2(i,2)-newV_OC1(i,2)*newV_OC2(i,1),newV_OC1(i,1)*newV_OC2(i,1)+newV_OC1(i,2)*newV_OC2(i,2));
     
     % Find the 3 bisector angles (with respect to positive x-axis)
     bisectorA = atan2(newV_OA(i,2),newV_OA(i,1));
     bisectorB = atan2(newV_OB(i,2),newV_OB(i,1));
     bisectorC = atan2(newV_OC(i,2),newV_OC(i,1));
     
     % Find maximum and minimum forces
     normMinA = 2*cos(angleDiffA/2)*minTension;
     normMaxA = 2*cos(angleDiffA/2)*maxTension;
     minA = [normMinA*cos(bisectorA) normMinA*sin(bisectorA)];
     maxA = [normMaxA*cos(bisectorA) normMaxA*sin(bisectorA)];
     
     normMinB = 2*cos(angleDiffB/2)*minTension;
     normMaxB = 2*cos(angleDiffB/2)*maxTension;
     minB = [normMinB*cos(bisectorB) normMinB*sin(bisectorB)];
     maxB = [normMaxB*cos(bisectorB) normMaxB*sin(bisectorB)];
     
     normMinC = 2*cos(angleDiffC/2)*minTension;
     normMaxC = 2*cos(angleDiffC/2)*maxTension;
     minC = [normMinC*cos(bisectorC) normMinC*sin(bisectorC)];
     maxC = [normMaxC*cos(bisectorC) normMaxC*sin(bisectorC)];
     
     
     % Find vertices of force hexagon
     vertex1 = maxA+minB+minC;
     vertex2 = maxA+maxB+minC;
     vertex3 = minA+maxB+minC;
     vertex4 = minA+maxB+maxC;
     vertex5 = minA+minB+maxC;
     vertex6 = maxA+minB+maxC;
     
     % Find "distance" to each side of force hexagon (ie. max force that can be
     % applied in each of limiting directions)
     side1(i) = signedPointLineDistance(0,0,vertex1(1),vertex1(2),vertex2(1),vertex2(2)); %Side between vertices 1 and 2
     side2(i) = signedPointLineDistance(0,0,vertex2(1),vertex2(2),vertex3(1),vertex3(2));
     side3(i) = signedPointLineDistance(0,0,vertex3(1),vertex3(2),vertex4(1),vertex4(2));
     side4(i) = signedPointLineDistance(0,0,vertex4(1),vertex4(2),vertex5(1),vertex5(2));
     side5(i) = signedPointLineDistance(0,0,vertex5(1),vertex5(2),vertex6(1),vertex6(2));
     side6(i) = signedPointLineDistance(0,0,vertex6(1),vertex6(2),vertex1(1),vertex1(2)); %Side between vertices 6 and 1
       
end


combined2 = [newX,newY,side1,side2,side3,side4,side5,side6];
    
TF4 = abs(combined2(:,3))<=targetForce ; %Note difference in Boolean variable number and side index
TF5 = abs(combined2(:,4))<=targetForce; 
TF6 = abs(combined2(:,5))<=targetForce; 
TF7 = abs(combined2(:,6))<=targetForce; 
TF8 = abs(combined2(:,7))<=targetForce; 
TF9 = abs(combined2(:,8))<=targetForce;
TF10 = combined2(:,3)>=0; 
TF11 = combined2(:,4)>=0; 
TF12 = combined2(:,5)>=0; 
TF13 = combined2(:,6)>=0; 
TF14 = combined2(:,7)>=0;
TF15 = combined2(:,8)>=0;

TFall2 = TF4 | TF5 | TF6 | TF7 | TF8 | TF9 | TF10 | TF11 | TF12 | TF13 | TF14 | TF15;
combined2(TFall2,:) = [];

WFWsize = size(combined2,1);

xWFW = combined2(:,1);
yWFW = combined2(:,2);

% Plot workspaces
figure
hold on;

% CHANGE COLOURS FOR NEXT PRESENTATION

% Plot WCW and WFW
h1 = scatter(combined1(:,1),combined1(:,2),50,'.','y');
h2 = scatter(combined2(:,1),combined2(:,2),50,'.','g')

% Plot circles at all attachment points, one colour per differential
diffA = [A1x A1y; A2x A2y];
diffB = [B1x B1y; B2x B2y];
diffC = [C1x C1y; C2x C2y];

h3 = scatter(diffA(:,1),diffA(:,2),100,'filled','o','r');
h4 = scatter(diffB(:,1),diffB(:,2),100,'filled','o','c');
h5 = scatter(diffC(:,1),diffC(:,2),100,'filled','o','k');


plot([MPx A1x], [MPy A1y],'r')
plot([MPx A2x], [MPy A2y],'r')
plot([MPx B1x], [MPy B1y],'c')
plot([MPx B2x], [MPy B2y],'c')
plot([MPx C1x], [MPy C1y],'k')
plot([MPx C2x], [MPy C2y],'k')

h6 = scatter(MPx,MPy,100,'filled','o','b');

xlabel({'x','/mm'})
ylabel({'y','/mm'})
axis equal;
xlim ([0 1000])
ylim ([0 1000])

legend([h1 h2 h3 h4 h5 h6],{'WCW','WFW','Differential A attachment points','Differential B attachment points','Differential C attachment points','MP'});
hold off;

% Workspace area calculation
WCWarea = WCWsize/gridSize^2
WFWarea = WFWsize/gridSize^2

% % Get cable lengths for WFW points
% lengthA = zeros(WFWsize,1);
% lengthB = zeros(WFWsize,1);
% lengthC = zeros(WFWsize,1); 
% 
% for i = 1:WFWsize
%     lengthA(i) = sqrt((xWFW(i)-A1x)^2+(yWFW(i)-A1y)^2)+sqrt((xWFW(i)-A2x)^2+(yWFW(i)-A2y)^2);
%     lengthB(i) = sqrt((xWFW(i)-B1x)^2+(yWFW(i)-B1y)^2)+sqrt((xWFW(i)-B2x)^2+(yWFW(i)-B2y)^2);
%     lengthC(i) = sqrt((xWFW(i)-C1x)^2+(yWFW(i)-C1y)^2)+sqrt((xWFW(i)-C2x)^2+(yWFW(i)-C2y)^2);
% end

% % Maximum and minimum legths for each cable
% lentghAmax = max(lengthA)
% lentghAmin = min(lengthA)
% lengthBmax = max(lengthB)
% lengthBmin = min(lengthB)
% lengthCmax = max(lengthC)
% lengthCmin = min(lengthC)

%Write points in WFW to CSV
WFW = [xWFW,yWFW];
filename = 'WFW.csv';
csvwrite(filename,WFW)

toc