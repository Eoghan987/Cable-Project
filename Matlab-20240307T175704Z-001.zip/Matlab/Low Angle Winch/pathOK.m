% Determines whether the points along a path (whose x and y coordinates are 
% the columns of 'path') are contained by the boundary defined by
% 'xBoundary' and 'yBoundary'

function ok = pathOK(path,xBoundary,yBoundary)

ok = true;

for i = 1:size(path,1)
    
    if not(inpolygon(path(i,1),path(i,2),xBoundary,yBoundary))
        ok = false;
        break
    end
    
end

end