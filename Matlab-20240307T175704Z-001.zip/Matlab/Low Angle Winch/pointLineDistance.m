function d = pointLineDistance(x0,y0,x1,y1,x2,y2)

%Returns the perpendicular distance from point (x0,y0) to the line segment
%between (x1,y1) and (x2,y2).

d = abs((y2-y1)*x0-(x2-x1)*y0+x2*y1-y2*x1)/sqrt((y2-y1)^2+(x2-x1)^2);