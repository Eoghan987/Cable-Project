clear all;
clc;

% Test settings
topSpeed = 8000; %Maximum allowed motor speed in steps / second [1 step = PI/100 rad]



testing = false; %Does not send serial commands to motors

% Inital position
xCurrent = 500;
yCurrent = 500;

% Winch calibration at I.P. ***Must be changed if not starting at (500,500)***
winds = [23 21 21]; % Number of full cable coils on each spool, updated during operation
initialWinds = winds; % Never changed
correction = [1.55 1.55 1.55]; % Experimentally determined correction factors for length control
diameter = zeros(1,3); % Keeps track of effective spool diameters
circumference = zeros(1,3); 
stepCount = [0 0 0]; % Counts steps to update "winds" as required


% Attachment point coordinates - *maintain anticlockwise order*
%A
A1x = 0;
A1y = 0;
A2x = 900; 
A2y = 0;
%B
B1x = 1000;
B1y = 100;
B2x = 1000;
B2y = 1000;
%C
C1x = 100;
C1y = 1000;
C2x = 0;
C2y = 900;


% Read workspace coordinates from accompanying script
filename = 'WFW.csv';
WFW = csvread(filename);

%Determine WFW boundary 
WFWx = WFW(:,1);
WFWy = WFW(:,2);
k = boundary(WFWx,WFWy);
xBoundary = WFWx(k);
yBoundary = WFWy(k);


% Plot current position and WFW
figure
hold on

hA = plot (WFWx(k),WFWy(k),'k');


h1 = plot([xCurrent A1x], [yCurrent A1y],'r');
h2 = plot([xCurrent A2x], [yCurrent A2y],'r');
h3 = plot([xCurrent B1x], [yCurrent B1y],'b');
h4 = plot([xCurrent B2x], [yCurrent B2y],'b');
h5 = plot([xCurrent C1x], [yCurrent C1y],'g');
h6 = plot([xCurrent C2x], [yCurrent C2y],'g');


hB = scatter(xCurrent,yCurrent,100,'filled','o','c');

xlabel({'x','/mm'})
ylabel({'y','/mm'})
axis equal
xlim ([0 1000])
ylim ([0 1000])
legend([hA hB],{'WFW boundary','Current position'});

hold off

while true    
    
    validCommand = false; % Flag goes positive when user enters a valid command
 
    while not(validCommand)
        % Prompt user for destination coordinates
        prompt = 'Enter the x coordinate of the destination [Enter x <0 or >1000 to exit.] ';
        xDest = input(prompt);
        
        if xDest > 1000 || xDest < 0
            close
            return
        end
        
        prompt = 'Enter the y coordinate of the destination. ';
        yDest = input(prompt);
        
        %Test if point inside WFW. If not, exit.
        if not(inpolygon(xDest,yDest,WFWx(k),WFWy(k)))
            disp ('Destination not in WFW.')
        else
            
            % Find a path if destination in WFW
            path = makePath(xCurrent,yCurrent,xDest,yDest);
            
            % Test if path contained by WFW
            if pathOK(path,xBoundary,yBoundary)
               validCommand = true;
            else
                % Attempt to generate a v-shaped path
                
                % Find midpoint
                midpoint = [(xCurrent+xDest)/2 (yCurrent+yDest)/2];
                % Find position vector from midpoint to destination
                toDest = [xDest-midpoint(1) yDest-midpoint(2)];
                % Make this a unit vector
                toDest = toDest/norm(toDest);
                %Find a perpendiculoar unit vector
                perpendicular = [-toDest(2) toDest(1)];
                
                for i = 1:10
                    
                    vertex = midpoint + 25*i*perpendicular;
                    pathA = makePath(xCurrent,yCurrent,vertex(1),vertex(2));
                    pathB = makePath(vertex(1),vertex(2),xDest,yDest);
                    path = [pathA; pathB];
                    
                    if pathOK(path,xBoundary,yBoundary)
                        break
                    end
                    
                    vertex = midpoint - 25*i*perpendicular;
                    pathA = makePath(xCurrent,yCurrent,vertex(1),vertex(2));
                    pathB = makePath(vertex(1),vertex(2),xDest,yDest);
                    path = [pathA; pathB];
                    
                    if pathOK(path,xBoundary,yBoundary)
                        break
                    end
                    
                end
                
                if pathOK(path,xBoundary,yBoundary)
                    validCommand = true;
                else
                    disp('Could not generate a path to this destination.')
                end

            end
            
        end
     
    end
    
    if validCommand
        
        close
        
        %Plot path
        figure
        hold on
        h1 = plot (WFWx(k),WFWy(k));
        h2 = plot (path(:,1), path(:,2));
        h3 = scatter (xCurrent, yCurrent);
        h4 = scatter (xDest, yDest);
        xlabel({'x','/mm'})
        ylabel({'y','/mm'})
        axis equal
        xlim ([0 1000])
        ylim ([0 1000])
        legend([h1 h2 h3 h4],{'WFW boundary','Path', 'Current position', 'Destination'});
        hold off
        
        %Find cable lengths at each point on path
        lengthA=zeros(size(path,1),1);
        lengthB=zeros(size(path,1),1);
        lengthC=zeros(size(path,1),1);
        
        for i = 1:length(path)
            lengthA(i) = sqrt((path(i,1)-A1x)^2+(path(i,2)-A1y)^2)+sqrt((path(i,1)-A2x)^2+(path(i,2)-A2y)^2)-7;
            lengthB(i) = sqrt((path(i,1)-B1x)^2+(path(i,2)-B1y)^2)+sqrt((path(i,1)-B2x)^2+(path(i,2)-B2y)^2)-7;
            lengthC(i) = sqrt((path(i,1)-C1x)^2+(path(i,2)-C1y)^2)+sqrt((path(i,1)-C2x)^2+(path(i,2)-C2y)^2)-7;
        end
        
        %Find the changes in cable lentghs between points
        deltaL = zeros(size(path,1)-1,3);
        
        for i = 1:size(deltaL,1)
            deltaL(i,1) = (lengthA(i+1)-lengthA(i));
            deltaL(i,2) = (lengthB(i+1)-lengthB(i));
            deltaL(i,3) = (lengthC(i+1)-lengthC(i));
        end
        
        steps = zeros(size(deltaL,1),3);
        
        for i = 1:size(steps,1)
            for j = 1:3
                diameter(j) = 30 + correction(j)*winds(j);
                circumference(j) = diameter(j) * pi;
                
                steps(i,j) = deltaL(i,j)/(circumference(j)/6533);
                stepCount(j) = stepCount(j) + steps(i,j);
                
                if stepCount(j) > 0 % i.e. less cable on spool than at inital position
                    winds(j) = initialWinds(j) - floor(stepCount(j)/6533);
                end
                
                if stepCount(j) <= 0 % i.e. more cable on spool than at inital position
                    winds(j) = initialWinds(j) - ceil(stepCount(j)/6533);
                end
            end
        end
        
        % Calculate the speeds at which to effect steps
        
        % At each part of the journey, the motor with the most steps to turn runs
        % at the set maximum  speed. The other motor speeds are scaled according to
        % the number of steps, so they all complete their motion simultaneously.
        
        speeds = zeros(size(steps,1),3);
        
        for i = 1:size(steps,1)
            for j = 1:3
                speeds(i,j) = topSpeed*steps(i,j)/max(abs(steps(i,:)));
            end
        end
        
        times = zeros(size(steps,1),3); %Time taken for each motor command
        
        % N.B. each row should contain 3 equal elements as each motor should take
        % the same time to effect the command motion.
        
        for i = 1:size(steps,1)
            for j = 1:3
                times(i,j) = steps(i,j)/speeds(i,j);
            end
        end
        
        if not(testing) %Loop to send commands to Arduino
            
            if ~isempty(instrfind)
                fclose(instrfind);
                delete(instrfind);
            end
            
            s=serial('COM13','BaudRate',115200);
            fopen(s);
                

            Load1 = zeros(size(steps,1),1); %testing load cell array
            Load2 = zeros(size(steps,1),1);
            Load3 = zeros(size(steps,1),1);
            
            Current1 = zeros(size(steps,1),1);
            Current2 = zeros(size(steps,1),1);
            Current3 = zeros(size(steps,1),1);
            
            Temp1 = zeros(size(steps,1),1);
            Temp2 = zeros(size(steps,1),1);
            Temp3 = zeros(size(steps,1),1);
            
             x = zeros(size(steps,1),1);
             for i = 1:size(steps,1)
                x(i) = i;    
             end
            
            
            for i = 1:size(steps,1)

                for j = 1:1 %Send three commands at a time (one for each motor)
                    % Command structure: Motor# Steps Speed
                    
                    command = [j steps(i,j) abs(speeds(i,j))];
                    
                    % Command formating: integer integer float (8 decimal places incl 4 after decimal point.)
                    formatSpec = '%d %8.3f %8.3f\n';
                    fprintf(s,formatSpec,command);
                    readData=fscanf(s); %Gets rid of command information from monitor


                    if(j == 1)  %stores numbers in array
                        
                        
                        
                         Force=fscanf(s); %Reads in force on load cell, in a char
                         CharToNum = str2num(Force); %change char to a number
                         Load1(i) = CharToNum; 
                        
                         Current=fscanf(s); %Reads in current, in a char
                         CharToNum = str2num(Current); %change char to a number
                         Current1(i) = CharToNum;
                 
%                          f1 =figure(2);
%                          scatter(x,Load1);
%                          movegui(f1,'north');
% 
% 
%                          f =figure(3);
%                          scatter(x,Current1);
%                          movegui(f,'south');
                         
                         f1 =figure(2);
                         subplot(2,1,1);
                         plot(x,Load1)
                         title('Load')
                         
                         subplot(2,1,2);
                         scatter(x,Current1)
                         title('Current over time')
                         suptitle('Master MicroController')
                         xlabel('Steps')
                         ylabel('Current (Amps)')
                         movegui(f1,'north');
                         
    
    
                         %pause(1);
                         
                    end
                    
                    if (j==2)
                        
                         Force=fscanf(s); %Reads in force on load cell, in a char
                         CharToNum = str2num(Force); %change char to a number
                         Load2(i) = CharToNum; 
                        
                         Current=fscanf(s); %Reads in current, in a char
                         CharToNum = str2num(Current); %change char to a number
                         Current2(i) = CharToNum;
                 
                         f1 =figure(3);
                         subplot(2,1,1);
                         plot(x,Load2)
                         title('Load')
                         
                         subplot(2,1,2);
                         scatter(x,Current2)
                         title('Current')
                         suptitle('Slave MicroController')
                         
                         movegui(f1,'northwest');
                         
    
                         pause(0.01);
                    end 
                    if (j==3)
                         Force=fscanf(s); %Reads in force on load cell, in a char
                         CharToNum = str2num(Force); %change char to a number
                         Load3(i) = CharToNum; 
                        
                         Current=fscanf(s); %Reads in current, in a char
                         CharToNum = str2num(Current); %change char to a number
                         Current3(i) = CharToNum;
                 
                         f1 =figure(4);
                         subplot(2,1,1);
                         plot(x,Load3)
                         title('Load')
                         
                         subplot(2,1,2);
                         scatter(x,Current3)
                         title('Current')
                         suptitle('Slave MicroController')
                         
                         movegui(f1,'northeast');
                         
    
                         pause(0.01);
                    end 

                end
                
                pause((times(i,j))+0.09); %Pause until motion complete before sending 3 more commands
            end
            
            
            
%             x = zeros(size(steps,1),1);
%             
%             for i = 1:size(steps,1)
%             x(i) = i;    
%             end
            
            
            %Loads = [Load1, Load2, Load3];
            %filename = 'Loads.csv';
            %csvwrite(filename,Loads)
            
            
%             scatter(x,Load1);
%             figure()
%             scatter(x,Current1);
%             figure()
%             scatter(x,Load2);
%             figure()
%             scatter(x,Current2);

        end
        
        
       % Update position
        xCurrent = xDest;
        yCurrent = yDest;
       
    end
    
    if not(testing)
        fclose(s);
    end
    
end