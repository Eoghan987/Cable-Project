function path = makePath(xCurrent,yCurrent,xDest,yDest)
    
points = round(sqrt((xDest-xCurrent)^2+(yDest-yCurrent)^2)/5)+1; % Number of points on path [interval ~ 25mm]
pathX = linspace(xCurrent,xDest,points); % Path x coordinates
pathY = linspace(yCurrent,yDest,points); % Path y coordinates
path = [pathX', pathY'];

end